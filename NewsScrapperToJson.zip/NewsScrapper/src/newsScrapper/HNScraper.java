package chapter3;

import java.util.List;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.gargoylesoftware.htmlunit.WebClient;
import com.gargoylesoftware.htmlunit.html.HtmlAnchor;
import com.gargoylesoftware.htmlunit.html.HtmlElement;
import com.gargoylesoftware.htmlunit.html.HtmlPage;

public class HNScraper {

	public static void main(String[] args) {
		String baseUrl = "https://www.ethiopianreporter.com" ;
		WebClient client = new WebClient();
		client.getOptions().setCssEnabled(false);
		client.getOptions().setJavaScriptEnabled(false);
		try{
			HtmlPage page = client.getPage(baseUrl);
			List<HtmlElement> itemList =  page.getByXPath("//div[@class='main main-page']");
			if(itemList.isEmpty()){
				System.out.println("No item found");
			}else{
				for(HtmlElement htmlItem : itemList){
					int position = Integer.parseInt(((HtmlElement) htmlItem.getFirstByXPath("./td/span")).asText().replace(".", ""));
					int id = Integer.parseInt(htmlItem.getAttribute("id"));
					String title =  ((HtmlElement) htmlItem.getFirstByXPath("//div[@class='post-title']")).asText();
					String url = ((HtmlAnchor) htmlItem.getFirstByXPath("//*[@id=\"block-gavias-kama-content\"]/div/article/div/div/div/div/div[1]/div/div/div/div/div/div[1]/div/div/div[1]/div/div/div/div/div/div[1]/div/div/div/div/div[2]/div[2]/a")).getHrefAttribute();
					String body =  ((HtmlElement) htmlItem.getFirstByXPath("//div[@class='post-body']")).asText();
					String more = ((HtmlElement) htmlItem.getFirstByXPath("//div[@class='view-node']")).asText();
					
					HackerNewsItem hnItem = new HackerNewsItem(title, url, body, more, position, id);
					
					ObjectMapper mapper = new ObjectMapper();
					String jsonString = mapper.writeValueAsString(hnItem) ;
					
					System.out.println(jsonString);
				}
			}
		}catch(Exception e){
			e.printStackTrace();
		}finally{
			client.close();
		}
	}
}
