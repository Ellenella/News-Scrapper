package chapter3;

public class HackerNewsItem {
	private String title;

	private String url ;
	private String body;
	private String more;
	private int position ;
	private int id ;
	
	public HackerNewsItem(String title, String url, String body, String more, int position, int id) {
		super();
		this.title = title;
		this.url = url;
		this.body = body;
		this.more = more;
		this.position = position;
		this.id = id;
	}
	
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public int getPosition() {
		return position;
	}
	public void setPosition(int position) {
		this.position = position;
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public String getUrl() {
		return url;
	}
	public void setUrl(String url) {
		this.url = url;
	}
	public String getBody() {
		return body;
	}
	public void setBody(String body) {
		this.body = body;
	}
	public int getMore() {
		return more;
	}
	public void setMore(int more) {
		this.more = more;
	}
	
}
